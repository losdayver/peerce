import { PeerProxy } from "@src/simple/simpleRelay";
export declare class PeerLossyProxy extends PeerProxy {
    /** [ 0, 1 ] */
    lossPercentage: number;
    constructor(address: string, port: number, 
    /** [ 0, 1 ] */
    lossPercentage?: number);
    private socket?;
    private ownPeer?;
    private distantPeer?;
    setup: PeerProxy["setup"];
    onDgram: (buffer: Buffer, fromAddress: string, fromPort: number) => void;
}
