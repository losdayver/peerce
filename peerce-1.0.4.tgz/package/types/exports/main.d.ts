import { SimplePeer as SimplePeerExport } from "@src/simple/simplePeer/simplePeer";
import { SimpleRelay as SimpleRelayExport } from "@src/simple/simpleRelay";
export declare const SimplePeer: typeof SimplePeerExport;
export declare const SimpleRelay: typeof SimpleRelayExport;
