import { EventEmitter } from "node:stream";
export declare const getResolver: () => {
    promise: Promise<unknown>;
    resolver: {
        resolve: (() => void) | undefined;
    };
};
export declare const sleep: (ms: number) => Promise<unknown>;
export declare const once: <T>(emitter: EventEmitter, event: string) => Promise<T>;
