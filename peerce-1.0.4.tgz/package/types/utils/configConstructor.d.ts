import { SimpleProtocolConfig, SimpleProtocolRelayConfig } from "@src/simple/simpleProtocol";
export interface FullConfig extends SimpleProtocolConfig, SimpleProtocolRelayConfig {
}
export declare const envConfig: FullConfig;
