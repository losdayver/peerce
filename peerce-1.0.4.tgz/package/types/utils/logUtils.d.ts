export declare const enum AnsiColor {
    BLACK = 30,
    RED = 31,
    GREEN = 32,
    YELLOW = 33,
    BLUE = 34,
    MAGENTA = 35,
    CYAN = 36,
    WHITE = 37,
    GRAY = 90,
    BRIGHTRED = 91,
    BRIGHTGREEN = 92,
    BRIGHTYELLOW = 93,
    BRIGHTBLUE = 94,
    BRIGHTMAGENTA = 95,
    BRIGHTCYAN = 96,
    BRIGHTWHITE = 97
}
export declare function colorLog(message?: unknown, color?: AnsiColor): void;
export declare const logInfo: (message: unknown) => void;
export declare const logWarning: (message: unknown) => void;
export declare const logError: (message: unknown) => void;
export declare function logProgress(prefix: string, percent: number, prefixColor?: AnsiColor): void;
