export declare function chunkBuffer(buffer: Buffer, chunkSize: number): Buffer[];
export declare function crc32(buffer: Buffer): number;
