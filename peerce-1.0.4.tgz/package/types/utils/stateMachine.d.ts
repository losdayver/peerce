type StateKeyType = string;
/** Declarations */
export type StateMachineConfig<ATM extends AvailableTransitionsMap = AvailableTransitionsMap, HandlerType extends Function = (...args: any[]) => void> = {
    atm: ATM;
    handler: HandlerType;
};
export type StateMachineLogicEntry<Config extends StateMachineConfig> = {
    onEnter?: (from: keyof Config["atm"] | null, params?: any) => void | Promise<void>;
    onExit?: (to: keyof Config["atm"]) => void | Promise<void>;
    logicHandler?: Config["handler"];
    [SK: string]: any;
};
export type AvailableTransitionsMap = Record<StateKeyType, StateKeyType[]>;
export type StateMachineLogic<Config extends StateMachineConfig> = {
    [K in keyof Config["atm"]]?: StateMachineLogicEntry<Config>;
};
export declare abstract class StateMachineLogicEntryBase<Config extends StateMachineConfig> implements StateMachineLogicEntry<Config> {
    logicHandler?: Config["handler"];
    onEnter?: (from: keyof Config["atm"] | null, params?: any) => void | Promise<void>;
    onExit?: (to: keyof Config["atm"]) => void | Promise<void>;
}
/** Use this to construct complex types */
export type InferStateMachineTypes<Config extends StateMachineConfig> = {
    StateMachine: StateMachine<Config>;
    Logic: StateMachineLogic<Config>;
    LogicEntry: StateMachineLogicEntry<Config>;
    LogicHandler: Config["handler"];
    ATM: Config["atm"];
    Config: Config;
};
/** Implementations */
export declare class StateMachine<Config extends StateMachineConfig> {
    private transitions;
    private logic;
    currentState: keyof Config["atm"];
    constructor(initialState: keyof Config["atm"], transitions: Config["atm"], logic: StateMachineLogic<Config>);
    fireLogicHandler(...args: Parameters<Config["handler"]>): void;
    canTransition(from: keyof Config["atm"], to: keyof Config["atm"]): boolean;
    doStateTransition<Params = unknown, ReturnT = unknown>(to: keyof Config["atm"], params?: Params): Promise<ReturnT | undefined>;
}
export {};
