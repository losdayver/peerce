import { StateMachine, StateMachineConfig, StateMachineLogic } from "@src/utils/stateMachine";
export declare const simplePeerStateTransitionMap: {
    idle: ["connectingToRelay", "error"];
    connectingToRelay: ["connectingToPeer", "error"];
    connectingToPeer: ["connectedToPeer", "error"];
    connectedToPeer: ["closing", "error"];
    closing: ["closed", "error"];
    closed: [];
    error: [];
};
export type SimplePeerStateMachineConfig = StateMachineConfig<typeof simplePeerStateTransitionMap, (params: any) => void>;
export type SimplePeerStateMachine = StateMachine<SimplePeerStateMachineConfig>;
export type SimplePeerStateMachineLogic = StateMachineLogic<SimplePeerStateMachineConfig>;
export type AvailableStateKeys = keyof SimplePeerStateMachineConfig["atm"];
