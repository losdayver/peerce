import { TransceiverIPv4 } from "@src/transport/transceiver";
import { PeerToPeerMessageDescriptor, PeerToPeerSessionRequest, SimpleProtocolPeerConfig } from "@src/simple/simpleProtocol";
import { SimplePeerStateMachine, SimplePeerStateMachineLogic } from "./stateMeta";
import { EventEmitter } from "node:stream";
interface SimplePeerEventEmitterMap {
    onConnectedToPeer: [sessionRequest: PeerToPeerSessionRequest];
    onFullMessage: [{
        buffer: Buffer;
        fileName: string;
    }];
}
export declare class SimplePeer {
    transceiver: TransceiverIPv4;
    stateMachine: SimplePeerStateMachine;
    eventEmitter: EventEmitter<SimplePeerEventEmitterMap>;
    initialParams: Required<SimpleProtocolPeerConfig>;
    constructor(initialParams: SimpleProtocolPeerConfig);
    simplePeerStateLogic: SimplePeerStateMachineLogic;
    requestSessionViaRelay: () => Promise<PeerToPeerSessionRequest>;
    sendData: ({ fileName, payload }: PeerToPeerMessageDescriptor) => void;
    close: () => void;
}
export {};
