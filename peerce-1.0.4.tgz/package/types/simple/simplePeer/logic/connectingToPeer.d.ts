import { StateMachineLogicEntryBase } from "@src/utils/stateMachine";
import { SimplePeerStateMachineConfig } from "@src/simple/simplePeer/stateMeta";
import { SimplePeer } from "@src/simple/simplePeer/simplePeer";
export declare class ConnectingToPeer extends StateMachineLogicEntryBase<SimplePeerStateMachineConfig> {
    simplePeer: SimplePeer;
    constructor(simplePeer: SimplePeer);
    onEnter: () => Promise<void>;
    onExit: () => void;
}
