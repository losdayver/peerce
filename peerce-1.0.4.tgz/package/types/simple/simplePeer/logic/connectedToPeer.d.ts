import { StateMachineLogicEntryBase } from "@src/utils/stateMachine";
import { SimplePeerStateMachineConfig } from "@src/simple/simplePeer/stateMeta";
import { SimplePeer } from "@src/simple/simplePeer/simplePeer";
import { PeerToPeerMessageDescriptor, PeerToPeerSessionRequest } from "@src/simple/simpleProtocol";
export type ConnectedToPeerLogicHandler = (params: PeerToPeerMessageDescriptor) => void;
export declare class ConnectedToPeer extends StateMachineLogicEntryBase<SimplePeerStateMachineConfig> {
    simplePeer: SimplePeer;
    constructor(simplePeer: SimplePeer);
    sessionRequest: PeerToPeerSessionRequest | undefined;
    chunkCollector: Map<string, Map<number, string>>;
    private addToChunkCollector;
    logicHandler: ConnectedToPeerLogicHandler;
    private onReceiveMsg;
    onEnter: (_: any, sessionRequest: PeerToPeerSessionRequest) => void;
    onExit: () => void;
}
