export declare const chunkPeerToPeerMessages: ({ payload, fileName, chunkLength, }: {
    payload: Buffer | string;
    fileName?: string;
    chunkLength?: number;
}) => Buffer[];
