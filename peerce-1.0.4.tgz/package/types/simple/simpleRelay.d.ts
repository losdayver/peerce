import { TransceiverIPv4 } from "@src/transport/transceiver";
export declare abstract class PeerProxy {
    readonly address: string;
    readonly port: number;
    constructor(address: string, port: number);
    abstract setup: (ownPeer: {
        address: string;
        port: number;
    }, distantPeer: {
        address: string;
        port: number;
    }) => void | Promise<void>;
}
type TagProxyMap = Record<string, PeerProxy>;
export declare class SimpleRelay {
    private tagProxyMap?;
    transceiver: TransceiverIPv4;
    private requestMap;
    constructor(address: string, port: number, tagProxyMap?: TagProxyMap | undefined);
    onSessionClosed: (address: string, port: number) => void;
    onReceiveFromPeer: (addrObj: {
        address: string;
        port: number;
    }, msg: Buffer) => Promise<void>;
}
export {};
