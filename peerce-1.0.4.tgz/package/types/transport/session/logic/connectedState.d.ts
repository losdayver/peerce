import { StateMachineLogicEntryBase } from "@src/utils/stateMachine";
import { SessionSMTypes } from "@src/transport/session/sessionMeta";
import { Session } from "@src/transport/session/session";
export declare class ConnectedState extends StateMachineLogicEntryBase<SessionSMTypes["Config"]> {
    session: Session;
    constructor(session: Session);
    private dataSender;
    private keepAliveNumSeconds;
    private keepAliveInterval;
    private readonly messageCollector;
    private sendAck;
    private collectDataMessagePart;
    onEnter: () => void;
    logicHandler: SessionSMTypes["LogicHandler"];
    onExit: () => void;
}
