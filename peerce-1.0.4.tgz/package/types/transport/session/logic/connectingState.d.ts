import { Session } from "@src/transport/session/session";
import { SessionSMTypes } from "@src/transport/session/sessionMeta";
import { StateMachineLogicEntryBase } from "@src/utils/stateMachine";
export declare class ConnectingState extends StateMachineLogicEntryBase<SessionSMTypes["Config"]> {
    private session;
    private retriesInterval?;
    private retriesNumSeconds;
    constructor(session: Session);
    onEnter: () => void;
    logicHandler: SessionSMTypes["LogicHandler"];
    onExit: () => void;
}
