import { StateMachineLogicEntryBase } from "@src/utils/stateMachine";
import { SessionSMTypes } from "@src/transport/session/sessionMeta";
import { Session } from "@src/transport/session/session";
export declare class ClosingState extends StateMachineLogicEntryBase<SessionSMTypes["Config"]> {
    private session;
    constructor(session: Session);
    onEnter: () => Promise<void>;
}
