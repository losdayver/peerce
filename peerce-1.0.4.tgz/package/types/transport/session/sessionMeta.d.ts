import { InferStateMachineTypes, StateMachineConfig } from "@src/utils/stateMachine";
import { Message } from "@src/transport/messageBuffer";
export declare const sessionStateTransitionMap: {
    idle: ["connecting", "error"];
    connecting: ["connected", "closing", "error"];
    connected: ["closing", "error"];
    closing: ["closed", "error"];
    closed: [];
    error: [];
};
export declare const enum SessionLogicHandlerAction {
    MESSAGE = 1,
    SEND_DATA = 2
}
type SessionLogicHandlerPairs = {
    action: SessionLogicHandlerAction.MESSAGE;
    payload: Message;
} | {
    action: SessionLogicHandlerAction.SEND_DATA;
    payload: string | Buffer;
};
type SessionSMConfig = StateMachineConfig<typeof sessionStateTransitionMap, (params: SessionLogicHandlerPairs) => void>;
export type SessionSMTypes = InferStateMachineTypes<SessionSMConfig>;
export {};
