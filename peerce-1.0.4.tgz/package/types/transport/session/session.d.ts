import { Message } from "@src/transport/messageBuffer";
import { TransceiverIPv4 } from "@src/transport/transceiver";
import { SessionSMTypes } from "@src/transport/session/sessionMeta";
export declare class Session {
    transceiverIPv4: TransceiverIPv4;
    address: string;
    port: number;
    constructor(transceiverIPv4: TransceiverIPv4, address: string, port: number);
    stateMachine: SessionSMTypes["StateMachine"];
    private sessionStateLogic;
    sendOne(message: Message): void;
    sendData(raw: string | Buffer): void;
    handleMessage(message: Message): void;
    connect: () => void;
    close: () => void;
}
