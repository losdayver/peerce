export declare const enum MessageType {
    HELLO = 0,
    HELLO_ACK = 1,
    DATA = 2,
    DATA_ACK = 3,
    KEEP_ALIVE = 4,
    FIN = 5
}
export interface Message {
    type: MessageType;
    uid?: number;
    seq?: number;
    total?: number;
    ack?: number;
    checksum?: number;
    payload?: Buffer;
}
export interface DataMessage extends Message {
    type: MessageType.DATA;
    uid: number;
    seq: number;
    total: number;
    ack: number;
    checksum: number;
    payload: Buffer;
}
export type DataAckMessage = Omit<Message, "seq" | "checksum" | "payload"> & {
    type: MessageType.DATA_ACK;
    uid: number;
    ack: number;
    total: number;
};
export declare class MessageBuffer {
    static maxPayloadSize: number;
    static decode(buffer: Buffer): Message | null;
    static construct(message: Message): {
        buffers: Buffer<ArrayBufferLike>[];
        total: number;
        uid: number;
    };
}
