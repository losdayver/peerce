import { EventEmitter } from "node:events";
interface TransceiverEventEmitterMap {
    onConnected: [address: string, port: number];
    onSessionClosed: [address: string, port: number];
    onClosed: [];
    onError: [];
    onReceive: [{
        address: string;
        port: number;
    }, msg: Buffer];
}
export interface TransceiverIPv4Params {
    self?: {
        address: string;
        port: number;
    };
}
export declare class TransceiverIPv4 {
    constructor();
    private socket;
    private selfAddress;
    private sessionMap;
    private stateMachine;
    private setupSocket;
    private bindSocketEvents;
    private onRawMessage;
    private transceiverStateLogic;
    eventEmitter: EventEmitter<TransceiverEventEmitterMap>;
    listen(self?: TransceiverIPv4Params["self"]): Promise<void>;
    connect(address: string, port: number): void;
    closeSession(address: string, port: number): void;
    close(): void;
    send(address: string, port: number, msg: string | Buffer): void;
    __send(address: string, port: number, msg: any): void;
    __deleteSessionFormMap(address: string, port: number): void;
}
export {};
